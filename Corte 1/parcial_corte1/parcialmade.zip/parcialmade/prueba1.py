from parcial1 import *

mi_lista = Lista(['a', 'b', 'c', 'c', 'c', 'c', 'd', 'e', 'e', 'e'])
print(mi_lista.dato_mas_comun()) # 'c'
print(mi_lista.cuenta_elementos('e')) # 3
